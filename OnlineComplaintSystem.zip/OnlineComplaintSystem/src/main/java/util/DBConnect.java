package util;

import java.sql.Connection;
import java.sql.DriverManager;

import jakarta.servlet.http.HttpServlet;

public class DBConnect extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static Connection conn;
    public static Connection getConnection() {
    	try 
    	{
    		if(conn == null) {
    			Class.forName("com.mysql.cj.jdbc.Driver");
    			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/complaint_db","root","ritesh123");
    			System.out.println("Database Connected !!!");
    		}
    	}
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return conn;
    }
    
}
