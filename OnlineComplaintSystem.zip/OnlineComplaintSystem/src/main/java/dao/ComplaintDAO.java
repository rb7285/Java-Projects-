package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServlet;
import model.Complaint;

public class ComplaintDAO extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private Connection conn;
    public ComplaintDAO(Connection conn) {
    	this.conn = conn;
    }
    
    public boolean fileComplaint(Complaint complaint) {
    	boolean success = false;
    	try {
    		String query = "insert into complaint(user_id,subject,description,status,created_at) values (?,?,?,?,?)";
    	    PreparedStatement ps = conn.prepareStatement(query);
    	    ps.setInt(1, complaint.getUserId());
    	    ps.setString(2, complaint.getSubject());
    	    ps.setString(3, complaint.getDescription());
    	    ps.setString(4, "Pending");
    	    ps.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
    	    
    	    success = ps.executeUpdate() > 0;
    	}
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return success;
    }
    
    public List<Complaint> getComplaintsByUserID(int user_id) {
    	List<Complaint> complaintList = new ArrayList<>();
    	try {
    		PreparedStatement ps = conn.prepareStatement("select * from complaint where user_id=?");
    		ps.setInt(1, user_id);
    		
    		ResultSet rs = ps.executeQuery();
    		while(rs.next()) {
    			Complaint complaint = new Complaint();
    			complaint.setId(rs.getInt("id"));
    			complaint.setUserId(rs.getInt("user_id"));
    			complaint.setSubject(rs.getString("subject"));
    			complaint.setDescription(rs.getString("description"));
    			complaint.setStatus(rs.getString("status"));
    			complaint.setCreatedAt(rs.getTimestamp("created_at"));
    			
    			complaintList.add(complaint);
    		}
    	}
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return complaintList;
    }
    
    public boolean updateComplaintStatus(int id, String status) {
    	boolean success = false;
    	try {
    		PreparedStatement ps = conn.prepareStatement("update complaints set status=? where id=?");
    		ps.setString(1,status);
    		ps.setInt(2, id);
    		
    		success = ps.executeUpdate() > 0;
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	}
    	return success;
    }
    
    public boolean deleteComplaint(int id) {
    	boolean success = false;
    	try {
    		PreparedStatement ps = conn.prepareStatement("delete from complaints where id=?");
    		ps.setInt(1, id);
    		
    		success = ps.executeUpdate() > 0;
    	}
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return success;
    }
}
