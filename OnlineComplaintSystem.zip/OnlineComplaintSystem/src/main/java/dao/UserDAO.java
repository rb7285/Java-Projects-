package dao;
import model.User; 

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.http.HttpServlet;
import util.DBConnect;

public class UserDAO extends HttpServlet {
	private static final long serialVersionUID = 1L;
     private Connection conn;
     public UserDAO(Connection conn) {
    	 this.conn = conn;
     }
     
     public boolean registerUser(User user) {
    	 boolean success = false;
    	 try {
    		 conn = DBConnect.getConnection();
    		 PreparedStatement ps = conn.prepareStatement("insert into users(name,email,password,role) values (?,?,?,?)");
    		 ps.setString(1, user.getName());
    		 ps.setString(2, user.getEmail());
    		 ps.setString(3, user.getPassword());
    		 ps.setString(4, "user");
    		 
    		 success = ps.executeUpdate() > 0;
    	 }
    	 catch(Exception e) {
    		 e.printStackTrace();
    	 }
    	 return success;
     }
     
     public User loginUser(String email, String password) {
    	 User user = null;
    	 try {
    		 PreparedStatement ps = conn.prepareStatement("select * from users where email=? and password=?");
    		 ps.setString(1, email);
    		 ps.setString(2, password);
    		 
    		 ResultSet rs = ps.executeQuery();
    		 
    		 if(rs.next()) {
    			 user = new User();
    			 user.setId(rs.getInt("id"));
                 user.setName(rs.getString("name"));
                 user.setEmail(rs.getString("email"));
                 user.setRole(rs.getString("role"));
    		 }
    	 }
    	 catch(Exception e) {
    		 e.printStackTrace();
    	 }
    	 return user;
     }
}
