package servlets;

import java.io.IOException;
import java.sql.Timestamp;

import dao.ComplaintDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Complaint;
import util.DBConnect;

@WebServlet("/FileComplaintServlet")
public class FileComplaintServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      int user_id = Integer.parseInt(request.getParameter("user_id"));
		  String subject = request.getParameter("subject");
	      String description = request.getParameter("description");
	      
	      Complaint complaint = new Complaint(user_id, subject, description, "Pending", new Timestamp(System.currentTimeMillis()));
	      
	      ComplaintDAO  dao = new ComplaintDAO(DBConnect.getConnection());
	      
	      boolean status = dao.fileComplaint(complaint);
	      
	      if(status) {
	    	  response.sendRedirect("dashboard.jsp?msg=success");
	      }
	      else {
	    	  response.sendRedirect("dashboard.jsp?msg=error");
	      }
	}

}
