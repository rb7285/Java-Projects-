package servlets;

import java.io.IOException;
import java.sql.Connection;

import dao.ComplaintDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.DBConnect;

@WebServlet("/DeleteComplaintServlet")
public class DeleteComplaintServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int complaintId = Integer.parseInt(request.getParameter("id"));

        Connection conn = DBConnect.getConnection();
        ComplaintDAO dao = new ComplaintDAO(conn);

        if (dao.deleteComplaint(complaintId)) {
            response.sendRedirect("view-complaints.jsp?success=deleted");
        } else {
            response.sendRedirect("view-complaints.jsp?error=deleteFailed");
        }
    }

}
