package servlets;

import java.io.IOException;

import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.User;
import util.DBConnect;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          String name = request.getParameter("name");
          String email = request.getParameter("email");
          String password = request.getParameter("password");
          
          User  user = new User(name,email,password,"user");
          UserDAO dao = new UserDAO(DBConnect.getConnection());
          boolean success = dao.registerUser(user);
          if(success) {
        	  response.sendRedirect("login.jsp?msg=registered");
          }
          else {
        	  response.sendRedirect("register.jsp?msg=error");
          }
          
	}

}
