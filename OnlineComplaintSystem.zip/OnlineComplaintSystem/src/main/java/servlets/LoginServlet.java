package servlets;

import java.io.IOException;

import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.User;
import util.DBConnect;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        UserDAO dao = new UserDAO(DBConnect.getConnection());
        User user = dao.loginUser(email, password);
        
        if(user!=null) {
        	HttpSession session = request.getSession();
        	session.setAttribute("userObj", user);
        	if(user.getRole().equals("admin")) {
        		response.sendRedirect("admin-dashboard.jsp");
        	}
        	else {
        		response.sendRedirect("dashboard.jsp");
        	}
        }
        else {
        	response.sendRedirect("login.jsp?msg=invalid");
        }
	}

}
