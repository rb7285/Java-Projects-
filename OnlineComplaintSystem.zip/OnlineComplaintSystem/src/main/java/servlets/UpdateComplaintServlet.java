package servlets;

import java.io.IOException;

import dao.ComplaintDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.DBConnect;

@WebServlet("/UpdateComplaintServlet")
public class UpdateComplaintServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
           int id = Integer.parseInt(request.getParameter("id"));
           String status = request.getParameter("status");
           
           ComplaintDAO dao = new ComplaintDAO(DBConnect.getConnection());
           
           if(dao.updateComplaintStatus(id, status)) {
        	   response.sendRedirect("view-complaints.jsp?success=updated");
           }
           else {
        	   response.sendRedirect("view-complaints.jsp?error=updateFailed");
           }
	}

}
