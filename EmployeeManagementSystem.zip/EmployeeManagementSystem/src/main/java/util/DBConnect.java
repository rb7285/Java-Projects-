package util;

import java.sql.Connection;
import java.sql.DriverManager;

import jakarta.servlet.http.HttpServlet;

public class DBConnect extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private static final String url = "jdbc:mysql://localhost/employeedb";
	private static final String user = "root";
	private static final String password = "ritesh123";
	
	public static Connection getConnection() {
		Connection conn = null;
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url,user,password);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return conn;
	}
}
