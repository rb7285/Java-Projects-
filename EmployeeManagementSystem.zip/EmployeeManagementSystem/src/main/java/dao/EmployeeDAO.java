package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.http.HttpServlet;
import model.Employee;
import util.DBConnect;

public class EmployeeDAO extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public void addEmployee(Employee emp) {
    	try 
    	{
    	Connection conn = DBConnect.getConnection();
    	PreparedStatement ps = conn.prepareStatement("Insert into employees(name,email,department,salary) values (?,?,?,?)");
    	ps.setString(1, emp.getName());
    	ps.setString(2,emp.getEmail());
    	ps.setString(3, emp.getDepartment());
    	ps.setDouble(4, emp.getSalary());
    	
    	ps.executeUpdate();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }
    
    public List<Employee> getAllEmployees(){
    	List<Employee> employees = new ArrayList<>();
    	try 
    	{
    		Connection conn = DBConnect.getConnection();
    		Statement stmt = conn.createStatement();
    		ResultSet rs = stmt.executeQuery("Select * from employees");
    		
    		while(rs.next())
    		{
    			employees.add(new Employee(
    					rs.getInt("id"),
    				    rs.getString("name"),
    				    rs.getString("email"),
    				    rs.getString("department"),
    				    rs.getDouble("salary")
    					));
    		}
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	return employees;
    }
    
    
    public Employee getEmployeeById(int id) {
    	Employee emp = null;
    	try 
    	{
    		Connection conn = DBConnect.getConnection();
    		PreparedStatement ps = conn.prepareStatement("select * from employees where id=?");
    		ps.setInt(1,id);
    		ResultSet rs= ps.executeQuery();
    		
    		while(rs.next()) {
    			emp = new Employee(
    					rs.getInt("id"),
    				    rs.getString("name"),
    				    rs.getString("email"),
    				    rs.getString("department"),
    				    rs.getDouble("salary")
    					);
    		}
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	return emp;
    }
    
    public void updateEmployee(Employee emp) {
    	try 
    	{
    		Connection conn = DBConnect.getConnection();
    		PreparedStatement ps = conn.prepareStatement("Update employees set name=?, email=?, department=?, salary=? where id=?");
    		ps.setString(1,emp.getName());
    		ps.setString(2,emp.getEmail());
    		ps.setString(3, emp.getDepartment());
    		ps.setDouble(4, emp.getSalary());
    		ps.setInt(5, emp.getId());
    		
    		ps.executeUpdate();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }
    
    public void deleteEmployee(int id) {
    	try 
    	{
    	    Connection conn = DBConnect.getConnection();
		    PreparedStatement ps = conn.prepareStatement("delete from employees where id=?");
		    ps.setInt(1, id);
		    ps.executeUpdate();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
		
    }

}
