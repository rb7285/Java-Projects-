package servlet;

import java.io.IOException;

import dao.EmployeeDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Employee;

@WebServlet("/editEmployee")
public class EditEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        int id = Integer.parseInt(request.getParameter("id"));
	        String name = request.getParameter("name");
	        String email = request.getParameter("email");
	        String department = request.getParameter("department");
	        double salary = Double.parseDouble(request.getParameter("salary"));
	        
	        Employee emp = new Employee(id, name, email, department, salary);
	        EmployeeDAO empdao = new EmployeeDAO();
	        empdao.updateEmployee(emp);
	        response.sendRedirect("viewEmployees");
	}

}
