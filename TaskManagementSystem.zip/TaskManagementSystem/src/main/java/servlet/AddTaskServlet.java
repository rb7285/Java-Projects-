package servlet;

import java.io.IOException;
import dao.TaskDAO;
import model.Task;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addTask")
public class AddTaskServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String status = request.getParameter("status");

        TaskDAO taskDAO = new TaskDAO();
        Task task = new Task(userId, title, description, status);

        boolean success = taskDAO.addTask(task);

        if (success) {
            response.sendRedirect("tasks.jsp"); // Redirect to task list
        } else {
            response.getWriter().println("Error: Task not added!");
        }
    }
}
